#--coding:utf-8--
import flask
from flask import jsonify 
from flask import request
from flask import send_file, send_from_directory
import pytesseract
import cv2 as cv
import requests
import os
import datetime



'''
 注册接口：
 post请求，请求参数入参类型json
 {
  "image_url":image_url  图片url
 }
'''

#创建一个接口服务
server = flask.Flask(__name__)
#注册路由
@server.route('/api', methods=['GET', 'POST'])

def api():
    #判断接口的请求方式是GET还是POST
    if request.method == 'GET':
        # 获取请求参数是json格式，返回结果是字典
        image_url = request.values.get("image_url")
    
    else:
        image_url = request.values.post("image_url")
    #return image_url
    #调用QCR_to_string方法处理图片文档提取
    status,data = QCR_to_string(image_url)
    data =data.encode("utf-8").decode("utf-8")
    print(data)
    #判断状态
    if status == 200:
        #成功
        return jsonify({"code": 200, "msg": "处理成功","data":data})
    return jsonify({"code": status, "msg": data,"data":"无"})
    
    
#QCR处理函数
def QCR_to_string(image_url):
    #网络图片获取
    image_data = requests.get(image_url).content
    #保存为一张图片
    f = open('test.png','wb')
    f.write(image_data)
    
    image = 'test.png'
    #读取一张图片
    img = cv.imread(image)
    print(img)
    #灰度处理
    gray = cv.cvtColor(img ,cv.COLOR_BGR2RGB)
    #提取字符
    text = pytesseract.image_to_string(gray,lang='chi_sim+eng')
    if text is not None:
        #删除图片
        os.remove(image)
        return 200,text
    else:
        return 500,"提取失败"


#文件上传
@server.route('/file' ,methods=['GET', 'POST'])
#上传图片
def file():
    file = request.files['file']
    filename =file.filename # 获取上传的文件名
    file.save('./image/{0}'.format(filename))  #
    img_path = "./image/{}".format(filename)
    #读取一张图片
    img = cv.imread(img_path)
    print(img)
    #灰度处理
    gray = cv.cvtColor(img ,cv.COLOR_BGR2RGB)
    #提取字符
    text = pytesseract.image_to_string(gray,lang='chi_sim+eng')
    if text is not None:
        #删除图片
        os.remove(img_path)
        return jsonify({"code": 200, "msg": "ok","data":text})
    else:
        return jsonify({"code": 500, "msg": "发生错误","data":"无"})


#file上传识别页面
@server.route('/file_page')
def file_page():
    return flask.render_template('qcr.html')
   


#文件上传
@server.route('/upload',methods=['POST','GET'])
def upload():
    if request.method == 'GET':
        return flask.render_template('upload.html')
    else:
	    # 判断是否有文件上传，防止出错
        if request.files:
        	f = request.files['file']
        	basedir = os.path.dirname(__file__)
        	# 获取系统时间
        	ftime = datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
        	# 拼成字符串
        	file_path = os.path.join(basedir,'./upload/images',ftime+f.filename)
        	f.save(file_path)
        	return '上传成功'
        	
        	
#下载文件
@server.route('/download/<filename>',methods=['POST','GET'])
def download(filename):
    #文件路径
    DOWNLOAD_FOLDER = "./download/"
    return send_from_directory(DOWNLOAD_FOLDER, filename, as_attachment=True)
  
	
 
if __name__ == '__main__':
      #port可以指定端口，默认端口是5000
      #host写成0.0.0.0的话，其他人可以访问，代表监听多块网卡上面，默认是127.0.0.1
      server.run(debug=False, port=8899, host='0.0.0.0')